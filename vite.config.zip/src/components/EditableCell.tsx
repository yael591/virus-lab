import { useEffect, useRef, useState, type KeyboardEvent } from 'react';

export type CellKind = 'text' | 'date' | 'list' | 'select';

interface Props {
  display: string;
  /** Raw value placed in the editor. */
  editValue: string;
  kind: CellKind;
  options?: string[];
  flagged: boolean;
  approved: boolean;
  title?: string;
  onSave: (v: string) => Promise<void> | void;
  onHover?: (el: HTMLElement | null) => void;
  ltr?: boolean;
  /** Unconfirmed reading shown as a hint; the field stays empty until accepted. */
  suggestion?: string;
}

export default function EditableCell({ display, editValue, kind, options, flagged, approved, title, onSave, onHover, ltr, suggestion }: Props) {
  const [editing, setEditing] = useState(false);
  const [v, setV] = useState(editValue);
  const [saving, setSaving] = useState(false);
  const ref = useRef<HTMLInputElement & HTMLSelectElement>(null);

  const startValue = editValue || (!display && suggestion ? suggestion : '');
  useEffect(() => { if (!editing) setV(startValue); }, [startValue, editing]);
  useEffect(() => { if (editing) ref.current?.focus(); }, [editing]);

  async function commit() {
    if (v.trim() === editValue.trim() && !(suggestion && !display && v.trim())) { setEditing(false); return; }
    setSaving(true);
    try { await onSave(v.trim()); setEditing(false); } finally { setSaving(false); }
  }
  function onKey(e: KeyboardEvent) {
    if (e.key === 'Enter') commit();
    if (e.key === 'Escape') { setV(startValue); setEditing(false); }
  }

  if (editing) {
    return kind === 'select' ? (
      <select ref={ref} className="cell-input" value={v} disabled={saving} onChange={(e) => setV(e.target.value)} onBlur={commit} onKeyDown={onKey}>
        <option value="">— בחרי —</option>
        {(options ?? []).map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    ) : (
      <input
        ref={ref}
        className="cell-input"
        dir={ltr ? 'ltr' : undefined}
        value={v}
        disabled={saving}
        placeholder={kind === 'date' ? 'DD/MM/YYYY' : kind === 'list' ? 'מופרדים בפסיק' : ''}
        onChange={(e) => setV(e.target.value)}
        onBlur={commit}
        onKeyDown={onKey}
      />
    );
  }

  const cls = ['cell', flagged && !approved ? 'flag' : '', !display ? 'empty' : ''].join(' ');
  return (
    <button
      type="button"
      className={cls}
      title={title}
      disabled={approved}
      onClick={() => setEditing(true)}
      onMouseEnter={(e) => onHover?.(e.currentTarget)}
      onMouseLeave={() => onHover?.(null)}
      onFocus={(e) => onHover?.(e.currentTarget)}
      onBlur={() => onHover?.(null)}
      dir={ltr ? 'ltr' : undefined}
    >
      {display || (suggestion ? <span className="suggest">הצעה: {suggestion}</span> : 'חסר')}
    </button>
  );
}
