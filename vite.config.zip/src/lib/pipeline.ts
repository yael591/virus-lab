// Upload pipeline: render → OCR (browser) → store image → extract (edge function) → zoom re-read.
// OCR of page n+1 overlaps the model call for page n. Extraction stays in page order
// so a continuation page always finds its previous page's form.

import { supabase } from './supabase.ts';
import { free, pagesOf, rotate, tiles, toJpeg, TILE_SOURCE_LONG_SIDE, type PageSource } from './render.ts';
import { ocrPage } from './ocr.ts';
import type { ZoomRequest } from '@engine/zoom.ts';

export type PageState = 'waiting' | 'ocr' | 'extracting' | 'rotating' | 'zoom' | 'done' | 'skipped' | 'error';
type Deg = 0 | 90 | 180 | 270;

export interface FileProgress {
  fileName: string;
  total: number;
  pages: PageState[];
  records: number;
  error?: string;
  startedAt: number;
  finishedAt?: number;
}

interface Prepared {
  path: string;
  rotation: Deg;
  row: Record<string, unknown>;
}

/** Render, OCR (optionally at a forced rotation), upload page image + zoom tiles. */
async function preparePage(batchId: string, src: PageSource, force?: Deg): Promise<Prepared> {
  const raw = await src.render();
  const ocr = await ocrPage(raw, force);
  if (ocr.canvas !== raw) free(raw);
  const rotation = ocr.rotation as Deg;
  const path = `${batchId}/${String(src.pageNo).padStart(3, '0')}.jpg`;
  const { error: upErr } = await supabase.storage.from('pages')
    .upload(path, await toJpeg(ocr.canvas), { contentType: 'image/jpeg', upsert: true });
  free(ocr.canvas);
  if (upErr) throw new Error(upErr.message);

  // zoom tiles are best effort: a failure here must not lose the page
  const tilePaths: string[] = [];
  try {
    const big = await src.render(TILE_SOURCE_LONG_SIDE);
    const hi = rotate(big, rotation);
    if (hi !== big) free(big);
    for (const [k, t] of tiles(hi).entries()) {
      const tp = path.replace(/\.jpg$/, `-t${k + 1}.jpg`);
      const { error } = await supabase.storage.from('pages').upload(tp, await toJpeg(t, 0.9), { contentType: 'image/jpeg', upsert: true });
      free(t);
      if (!error) tilePaths.push(tp);
    }
    free(hi);
  } catch (e) {
    console.warn('tiles skipped', e);
  }
  return {
    path,
    rotation,
    row: {
      image_path: path,
      tile_paths: tilePaths,
      rotation,
      ocr_text: ocr.text,
      ocr_layout: ocr.layout,
      ocr_confidence: ocr.confidence,
    },
  };
}

export async function processFile(file: File, onProgress: (p: FileProgress) => void): Promise<void> {
  const prog: FileProgress = { fileName: file.name, total: 0, pages: [], records: 0, startedAt: Date.now() };
  const emit = () => onProgress({ ...prog, pages: [...prog.pages] });

  try {
    const sources = await pagesOf(file);
    prog.total = sources.length;
    prog.pages = sources.map(() => 'waiting');
    emit();

    const { data: batch, error: bErr } = await supabase.from('batches')
      .insert({ file_name: file.name, page_count: sources.length }).select('id').single();
    if (bErr || !batch) throw new Error(bErr?.message ?? 'batch insert failed');

    let extractChain: Promise<void> = Promise.resolve();

    for (const src of sources) {
      const i = src.pageNo - 1;
      prog.pages[i] = 'ocr';
      emit();

      let prep: Prepared;
      let page: { id: string };
      try {
        prep = await preparePage(batch.id, src);
        const { data, error: pErr } = await supabase.from('pages')
          .insert({ batch_id: batch.id, page_no: src.pageNo, ...prep.row }).select('id').single();
        if (pErr || !data) throw new Error(pErr?.message ?? 'page insert failed');
        page = data;
      } catch (e) {
        // one bad page must not stop the file
        console.error(`page ${src.pageNo} failed`, e);
        prog.pages[i] = 'error';
        emit();
        continue;
      }

      prog.pages[i] = 'extracting';
      emit();

      extractChain = extractChain.then(async () => {
       try {
        let res = await extractPage(page.id, true);
        if (res.rotate) {
          // the model saw a sideways page: rotate, re-OCR, re-extract once
          prog.pages[i] = 'rotating';
          emit();
          const deg = ((prep.rotation + res.rotate) % 360) as Deg;
          prep = await preparePage(batch.id, src, deg);
          await supabase.from('pages').update(prep.row).eq('id', page.id);
          res = await extractPage(page.id, false);
        }
        prog.records += res.records;
        if (res.formId && res.zoom.length) {
          prog.pages[i] = 'zoom';
          emit();
          const rot = prep.rotation;
          await zoomReread(res.formId, prep.path, res.zoom, () => src.render(ZOOM_LONG_SIDE).then((c) => rotate(c, rot)));
        }
        prog.pages[i] = res.state;
        emit();
       } catch (e) {
        console.error(`page ${src.pageNo} extraction failed`, e);
        prog.pages[i] = 'error';
        emit();
       }
      });
    }

    await extractChain;
  } catch (e) {
    prog.error = e instanceof Error ? e.message : String(e);
  }
  prog.finishedAt = Date.now();
  emit();
}

export interface ExtractResult {
  state: PageState;
  records: number;
  formId: string | null;
  zoom: ZoomRequest[];
  rotate?: number;
}

export async function extractPage(pageId: string, allowRotate = true): Promise<ExtractResult> {
  const { data, error } = await supabase.functions.invoke('extract', { body: { page_id: pageId, allow_rotate: allowRotate } });
  if (error || !data?.ok) return { state: 'error', records: 0, formId: null, zoom: [] };
  if (data.rotate) return { state: 'extracting', records: 0, formId: null, zoom: [], rotate: data.rotate };
  if (data.skipped) return { state: 'skipped', records: 0, formId: null, zoom: [] };
  return { state: 'done', records: data.records ?? data.added ?? 0, formId: data.form_id ?? null, zoom: data.zoom ?? [] };
}

/** Long side of the render used for zoom crops: high enough that a name line is hundreds of px wide. */
const ZOOM_LONG_SIDE = 4200;

/**
 * Crop each uncertain field's area from a fresh high-resolution render and ask for a
 * focused re-read. Best effort: any failure leaves the first-pass result as it is.
 */
async function zoomReread(formId: string, pagePath: string, zoom: ZoomRequest[], renderHi: () => Promise<HTMLCanvasElement>) {
  try {
    const hi = await renderHi();
    const crops: { field: string; path: string; record_id?: string }[] = [];
    for (const z of zoom) {
      const [x0, y0, x1, y1] = z.box;
      const sx = Math.round(x0 * hi.width), sy = Math.round(y0 * hi.height);
      const sw = Math.round((x1 - x0) * hi.width), sh = Math.round((y1 - y0) * hi.height);
      if (sw < 20 || sh < 20) continue;
      const scale = Math.min(1, 1500 / Math.max(sw, sh));
      const c = document.createElement('canvas');
      c.width = Math.round(sw * scale);
      c.height = Math.round(sh * scale);
      const ctx = c.getContext('2d')!;
      // sharpen faint pen: more contrast and colour, keeps blue ink distinct from print
      ctx.filter = 'contrast(1.35) saturate(1.4)';
      ctx.drawImage(hi, sx, sy, sw, sh, 0, 0, c.width, c.height);
      const p = pagePath.replace(/\.jpg$/, `-z-${z.field}${z.record_id ? '-' + z.record_id.slice(0, 8) : ''}.jpg`);
      const { error } = await supabase.storage.from('pages').upload(p, await toJpeg(c, 0.92), { contentType: 'image/jpeg', upsert: true });
      free(c);
      if (!error) crops.push({ field: z.field, path: p, record_id: z.record_id });
    }
    free(hi);
    if (crops.length) await supabase.functions.invoke('reread', { body: { form_id: formId, crops } });
  } catch (e) {
    console.warn('zoom re-read skipped', e);
  }
}
