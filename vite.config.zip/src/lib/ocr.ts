// In-browser OCR (Tesseract, Hebrew + English). Page text never goes to an extra
// external service: it is computed here and stored only in our own database.

import { createWorker, type Worker } from 'tesseract.js';
import type { OcrLayout } from '@engine/types.ts';
import { enhanced, free, rotate, toJpeg } from './render.ts';

let workerP: Promise<Worker> | null = null;
function worker(): Promise<Worker> {
  if (!workerP) workerP = createWorker('heb+eng');
  return workerP;
}

export interface OcrResult {
  text: string;
  layout: OcrLayout;
  confidence: number;
}

async function recognize(canvas: HTMLCanvasElement): Promise<OcrResult> {
  const w = await worker();
  const e = enhanced(canvas);
  let data: Awaited<ReturnType<Worker['recognize']>>['data'];
  try {
    ({ data } = await w.recognize(e));
  } catch {
    // some browsers fail to hand a canvas to the worker under memory pressure — retry as a JPEG blob
    ({ data } = await w.recognize(await toJpeg(e, 0.92)));
  } finally {
    free(e);
  }
  return {
    text: data.text ?? '',
    confidence: data.confidence ?? 0,
    layout: {
      width: canvas.width,
      height: canvas.height,
      words: (data.words ?? [])
        .filter((wd) => wd.text?.trim())
        .map((wd) => ({ t: wd.text, x0: wd.bbox.x0, y0: wd.bbox.y0, x1: wd.bbox.x1, y1: wd.bbox.y1 })),
    },
  };
}

const LOW_CONFIDENCE = 45;

/**
 * OCR with orientation recovery: if the upright read is poor, try the other three
 * rotations and keep the best. Returns the canvas actually used, so stored image,
 * word boxes and crops all share one geometry.
 */
export async function ocrPage(canvas: HTMLCanvasElement, force?: 0 | 90 | 180 | 270): Promise<OcrResult & { canvas: HTMLCanvasElement; rotation: number }> {
  if (force !== undefined) {
    const c = rotate(canvas, force);
    return { ...(await recognize(c)), canvas: c, rotation: force };
  }
  let best = { ...(await recognize(canvas)), canvas, rotation: 0 };
  if (best.confidence >= LOW_CONFIDENCE) return best;
  for (const deg of [180, 90, 270] as const) {
    const c = rotate(canvas, deg);
    const r = await recognize(c);
    if (r.confidence > best.confidence + 5) {
      if (best.canvas !== canvas) free(best.canvas);
      best = { ...r, canvas: c, rotation: deg };
    } else free(c);
    if (best.confidence >= LOW_CONFIDENCE + 15) break;
  }
  return best;
}
